<div class="content-error d-flex flex-fill align-items-center h-v-80">
    <div class="text-center p-5 mx-auto">
        <div class="d-inline-block svg-lg svg-empty"></div>
        <p class="text-lg text-muted mt-3 mt-md-4"><?php esc_html_e( 'It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'pandapro' ); ?></p>
    </div>
</div>
